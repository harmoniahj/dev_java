package test;

import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Vector;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import design.zipcode.MemberShip;
import design.zipcode.ZipCodeVO;
import util.DBConnection;

public class Test3 extends JFrame implements MouseListener , ItemListener, FocusListener, ActionListener{
	String zdo 		= null;
	String sigu 	= null;
	String dong 	= null;
 // 물리적으로 떨어져 있는 db서버와 연결통로 만들기
	JPanel jp_north = new JPanel();
	
	String sigus[] = null;
	String dongs[] = null;
	String zdos3[] = null;
	String totals[] = {"전체"};
	Vector<String> vzdos = new Vector<>(); // vzdos.size()==>0
	JComboBox jcb_zdo 	= null; // zdo
	JComboBox jcb_sigu 	= null; // West
	JComboBox jcb_dong 	= null; // West
	JTextField jtf_search = new JTextField("동이름을 입력하세요.",20); // Center
	JButton jbtn_search = new JButton("조회");//East
	String cols[] = {"ChkBox","주소","우편번호"};
	String data[][] = new String[0][3];
	DefaultTableModel dtm_zipcode = new DefaultTableModel(data,cols);
	JTable jtb_zipcode = new JTable(dtm_zipcode);
	
	JTableHeader jth = jtb_zipcode.getTableHeader();
	JScrollPane jsp_zipcode = new JScrollPane(jtb_zipcode, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
														 , JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	MemberShip memberShip = null;
// DB연동에 필요한 선언
	DBConnection dbMgr = DBConnection.getInstance();
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	public Test3() {
		zdos3 = getZDOList();
		jcb_zdo = new JComboBox(zdos3);//West
		jcb_sigu = new JComboBox(totals);//West
		jcb_dong = new JComboBox(totals);//West
	}
 
	public String[] getSiguList(String pzdo) {
		String sigus[] = null; // 리턴타입을 1차 배열로 했으므로 1차배열 선언하기
	// 오라클 서버에게 보낼 select문 작성, String은 원본이 바뀌지 않음.
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT '전체' sigu FROM dual UNION ALL ");
		sb.append("SELECT sigu FROM (SELECT distinct(sigu) sigu ");
		sb.append(" FROM zipcode_t WHERE zdo=? ORDER BY sigu asc)");
		try {
			con = dbMgr.getConnection();
			pstmt = con.prepareStatement(sb.toString());
			pstmt.setString(1,pzdo);
			rs = pstmt.executeQuery();
			Vector<String> v = new Vector<>();
			while(rs.next()) {
				String sigu = rs.getString("sigu");
				v.add(sigu);
			}
			sigus = new String[v.size()];
			v.copyInto(sigus);
		} catch (Exception e) {		
			e.printStackTrace();
		}
		return sigus;
	}
	
	public String[] getDongList(String psigu) {
		String dongs[] = null;
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT '전체' dong FROM dual UNION ALL ");
		sb.append("SELECT dong FROM ");
		sb.append(" (SELECT distinct(dong) dong  FROM zipcode_t WHERE sigu=? ORDER BY dong asc)");
		try {
			con = dbMgr.getConnection();
			pstmt = con.prepareStatement(sb.toString());
			pstmt.setString(1,psigu);
			rs = pstmt.executeQuery();
			Vector<String> v = new Vector<>();
			while(rs.next()) {
				String dong = rs.getString("dong");
				v.add(dong);
			}
			dongs = new String[v.size()];
			v.copyInto(dongs);
		} catch (Exception e) {			
			e.printStackTrace();
		}
		return dongs;
	}
	
	public Test3(MemberShip memberShip) {
		this();
		this.memberShip = memberShip;
	}
	
	public void initDisplay() {
		jtb_zipcode.getColumn("ChkBox").setCellRenderer(dcr);
		JCheckBox box = new JCheckBox();
		box.setHorizontalAlignment(JLabel.CENTER);
		jtb_zipcode.getColumn("ChkBox").setCellEditor(new DefaultCellEditor(box));
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		jth.setBackground(Color.blue);
		jth.setForeground(Color.white);
		jth.setFont(new Font("맑은고딕",Font.BOLD,24));
		
		jtb_zipcode.getColumnModel().getColumn(0).setPreferredWidth(100);
		jtb_zipcode.getColumnModel().getColumn(1).setPreferredWidth(300);
		jtb_zipcode.requestFocus();
		
		jtb_zipcode.addMouseListener(this);
		jbtn_search.addActionListener(this);
		jtf_search.addFocusListener(this);
		jtf_search.addActionListener(this);
		
		jp_north.setLayout(new FlowLayout());

		jcb_sigu.addItemListener(this);
		jcb_dong.addItemListener(this);
		jcb_zdo.addItemListener(this);
		
		jp_north.add(jcb_zdo);
		jp_north.add(jcb_sigu);
		jp_north.add(jcb_dong);
		jp_north.add(jtf_search);
		jp_north.add(jbtn_search);
		jp_north.setBackground(Color.red);
		
		this.add("North",jp_north);
		this.add("Center",jsp_zipcode);
		this.setTitle("우편번호 검색");
		this.setSize(700, 650);
		this.setVisible(true);
	}
 // 콤보박스에 뿌려질 ZDO컬럼의 정보를 오라클 서버에서 꺼내 오기
	public String[] getZDOList() {
		// 조회 결과를 받을 1차 문자 배열 선언. 초기화는 안함.
		String zdos[] = null;
		StringBuilder sb = new StringBuilder();
		sb.append("SELECT '전체' zdo FROM dual UNION ALL ");
		sb.append("SELECT zdo FROM ");
		sb.append("(SELECT distinct(zdo) zdo FROM zipcode_t ORDER BY zdo asc)");
		try {
			con = dbMgr.getConnection();
			pstmt = con.prepareStatement(sb.toString());
			rs = pstmt.executeQuery();
			Vector<String> v = new Vector<>();
			List<String> v2 = new Vector<>();
			while(rs.next()) {
				String zdo = rs.getString("zdo");
				v.add(zdo);
			}
			zdos = new String[v.size()];
			v.copyInto(zdos);
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			
		}
		return zdos;
	}
	
	public static void main(String[] args) {
		JFrame.setDefaultLookAndFeelDecorated(true);
		Test3 zcs = new Test3();
		zcs.initDisplay();
	}
	
	@Override
	public void focusGained(FocusEvent e) {
		if(e.getSource() == jtf_search) {
			jtf_search.setText("");
		}
	}
	
	@Override
	public void focusLost(FocusEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	public void refreshData(String zdo, String dong) {
		System.out.println("zdo:"+zdo+", dong:"+dong);
		
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT 'false' ChkBox,  address, zipcode");
		sql.append("  FROM zipcode_t");
		sql.append(" WHERE 1=1");
		if(zdo!=null && zdo.length()>0) {
			sql.append(" AND zdo=?");
		}
		if(dong!=null && dong.length()>0) {
			sql.append(" AND dong LIKE '%'||?||'%'");
		}
		int i=1;
		try {
			con = dbMgr.getConnection();
			pstmt = con.prepareStatement(sql.toString());
			if(zdo!=null && zdo.length()>0) {
				pstmt.setString(i++,zdo);
			}
			if(dong!=null && dong.length()>0) {
				pstmt.setString(i++,dong);
			}			
			rs = pstmt.executeQuery();
			Vector<ZipCodeVO> v = new Vector<>();
			ZipCodeVO[] zVOS = null;
			ZipCodeVO zVO = null;
			while(rs.next()) {
				zVO = new ZipCodeVO();
				Boolean chkBox = Boolean.parseBoolean(rs.getString("ChkBox"));
				zVO.setChkBox(chkBox);
				zVO.setAddress(rs.getString("address"));
				zVO.setZipcode(rs.getInt("zipcode"));
				v.add(zVO);
			}
			zVOS = new ZipCodeVO[v.size()];
			v.copyInto(zVOS);
			if(v.size()>0) {
			// 조회 버튼을 연달아서 눌럿을 경우 기존에 조회 결과는 클리어 시킴
				while(dtm_zipcode.getRowCount()>0) {
					dtm_zipcode.removeRow(0);
				}
			// 새로 조회된 결과를 출력하기
				for(int x=0;x<v.size();x++) {
					Vector<Object> 		oneRow 	= new Vector<>();
					oneRow.add(0,zVOS[x].getChkBox());
					oneRow.add(1,zVOS[x].getAddress());	
					oneRow.add(2,zVOS[x].getZipcode());		
					dtm_zipcode.addRow(oneRow); // 오직 객체 배열과 벡터 뿐
				}
			}
		} catch (SQLException se) {
			System.out.println("[[ query ]]"+sql.toString());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dbMgr.freeConnection(con, pstmt, rs);
		}
		
	}/////////////////end of refreshData
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		if(obj == jbtn_search || obj == jtf_search) {
			String myDong = jtf_search.getText();
			refreshData(zdo,myDong);
		}
	}
	
	@Override
	public void itemStateChanged(ItemEvent ie) {
		Object obj = ie.getSource();
		if(obj == jcb_zdo) {
			if(ie.getStateChange() == ItemEvent.SELECTED) {
				zdo = zdos3[jcb_zdo.getSelectedIndex()];
				sigus = getSiguList(zdo);
				jcb_sigu.removeAllItems();
				
				for(int i=0;i<sigus.length;i++) {
					jcb_sigu.addItem(sigus[i]);
				}
			}
		}
		
		if(obj == jcb_sigu) {
			if(ie.getStateChange() == ItemEvent.SELECTED) {
				sigu = sigus[jcb_sigu.getSelectedIndex()];
				dongs = getDongList(sigu);
				jcb_dong.removeAllItems();
				
				for(int i=0;i<dongs.length;i++) {
					jcb_dong.addItem(dongs[i]);
				}
			}
		}
		if(obj == jcb_dong) {
			if(ie.getStateChange() == ItemEvent.SELECTED) {
				dong = dongs[jcb_dong.getSelectedIndex()];
			}
		}

		
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent e) {
		if(e.getClickCount()==2) {
			int index[] = jtb_zipcode.getSelectedRows();
			for(int i=0;i<dtm_zipcode.getRowCount();i++) {
				if(jtb_zipcode.isRowSelected(i)) {
					//System.out.println("zipcode : "+dtm_zipcode.getValueAt(i, 1));
					String address = dtm_zipcode.getValueAt(i, 2).toString();
					memberShip.jtf_zipcode.setText(String.valueOf(dtm_zipcode.getValueAt(i, 1)));
					memberShip.jtf_address.setText(address);
				}
			}
		}
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	/////////////////// 체크 박스 추가 ////////////////////////
	DefaultTableCellRenderer dcr = new DefaultTableCellRenderer() {
	  public Component getTableCellRendererComponent  // 셀렌더러
	   (JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
		  JCheckBox box= new JCheckBox();
		  box.setSelected(((Boolean)value).booleanValue());   
		  box.setHorizontalAlignment(JLabel.CENTER);
		  return box;
	  }
	};	
}