package test;

public class Test2 {
	void forMethod() {
		for(int i=1; i<101; i++) {
	        if(i%5 == 0 && i%7 == 0) {
	            System.out.print("fizzbuzz ");
	        }
	        else if(i%5 == 0) {
	            System.out.print("fizz ");
	        }
	        else if(i%7 == 0) {
	            System.out.print("buzz ");
	        }
	        else {
				System.out.print(i);
	        }
	    }
	}
	
	void WhileMethod() {
		int i=1;
		while(i < 101) {
			if(i%5 == 0 && i%7 == 0) {
                System.out.print("fizzbuzz ");
            }
            else if(i%5 == 0) {
                System.out.print("fizz ");
            }
            else if(i%7 == 0) {
                System.out.print("buzz ");
            }
            else {
				System.out.print(i);
	        }
            i++;
        }
    }

	public static void main(String[] args) {
		Test2 t2 = new Test2();
		System.out.println("for문");
		t2.forMethod();
		
		System.out.println("");
		System.out.println("while문");
		t2.WhileMethod();
	}
}